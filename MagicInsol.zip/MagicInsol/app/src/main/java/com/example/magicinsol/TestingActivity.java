package com.example.magicinsol;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

public class TestingActivity extends AppCompatActivity {
    private SensorManager sensorManager;
    private TextView count;
    private TextView weights;
    private TextView heights;
    boolean activityRunning;
    private long timeWhenStopped = 0;
    private boolean stopClicked;
    private Chronometer chronometer;
    private Toolbar supportActionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testing);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        count = (TextView) findViewById(R.id.count);
        weights = (TextView) findViewById(R.id.weight);
        heights = (TextView) findViewById(R.id.height);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        chronometer = (Chronometer) findViewById(R.id.chronometer);

    }

    @Override
    protected void onPause(){
        super.onPause();
        activityRunning= false;
    }
    public void startButtonClick(View v) {
        chronometer.setBase(SystemClock.elapsedRealtime() + timeWhenStopped);
        chronometer.start();
        stopClicked = false;

    }
}