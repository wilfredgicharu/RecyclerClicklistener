package com.example.magicinsol;

import androidx.appcompat.app.AppCompatActivity;

public class Bluetooth  {
}
