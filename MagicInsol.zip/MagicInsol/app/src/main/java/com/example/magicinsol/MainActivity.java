package com.example.magicinsol;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    private BluetoothAdapter BTAdapter;

    public static int REQUEST_BLUETOOTH= 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button displayButton = (Button) findViewById(R.id.button_next);
        displayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Timeline.class));
            }

        });

        BTAdapter = BluetoothAdapter.getDefaultAdapter();
        ImageButton bluetoothbtn= findViewById(R.id.bluetooth_btn);

        bluetoothbtn.setOnClickListener(view ->{
            Intent bluetoothIntent;
            bluetoothIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(bluetoothIntent,1);
        });

        if (BTAdapter == null){
            new AlertDialog.Builder(this).setTitle("Not compatible").setMessage("Your phone does not support Bluetooth").setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    System.exit(0);
                }
            }).setIcon(android.R.drawable.ic_dialog_alert).show();
        }
    }

}